import request from '@/utils/request'

// 查询设施和宝物关系表列表
export function listTreasure_1(query) {
  return request({
    url: '/system/treasure_1/list',
    method: 'get',
    params: query
  })
}

// 查询设施和宝物关系表详细
export function getTreasure_1(id) {
  return request({
    url: '/system/treasure_1/' + id,
    method: 'get'
  })
}

// 新增设施和宝物关系表
export function addTreasure_1(data) {
  return request({
    url: '/system/treasure_1',
    method: 'post',
    data: data
  })
}

// 修改设施和宝物关系表
export function updateTreasure_1(data) {
  return request({
    url: '/system/treasure_1',
    method: 'put',
    data: data
  })
}

// 删除设施和宝物关系表
export function delTreasure_1(id) {
  return request({
    url: '/system/treasure_1/' + id,
    method: 'delete'
  })
}
