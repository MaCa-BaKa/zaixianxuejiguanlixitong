import request from '@/utils/request'

// 查询设施和人物关系表列表
export function listKeyman_fac(query) {
  return request({
    url: '/system/keyman_fac/list',
    method: 'get',
    params: query
  })
}

// 查询设施和人物关系表详细
export function getKeyman_fac(id) {
  return request({
    url: '/system/keyman_fac/' + id,
    method: 'get'
  })
}

// 新增设施和人物关系表
export function addKeyman_fac(data) {
  return request({
    url: '/system/keyman_fac',
    method: 'post',
    data: data
  })
}

// 修改设施和人物关系表
export function updateKeyman_fac(data) {
  return request({
    url: '/system/keyman_fac',
    method: 'put',
    data: data
  })
}

// 删除设施和人物关系表
export function delKeyman_fac(id) {
  return request({
    url: '/system/keyman_fac/' + id,
    method: 'delete'
  })
}
